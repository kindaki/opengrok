#!/bin/bash
cd ./scripts
./del.sh


