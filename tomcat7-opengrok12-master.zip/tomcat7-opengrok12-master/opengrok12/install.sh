#!/bin/bash
#./insall.sh 创建名 代码路径 root密码
#./insall.sh mt6737_android_8_1  /home/XXX/mt6737  1234679
cd ./scripts
./setup.sh $1 $2


