int a (void)
{
  return 0;
}
