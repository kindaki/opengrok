struct {
	int a;
} A;

struct {
	int b;
} B;
